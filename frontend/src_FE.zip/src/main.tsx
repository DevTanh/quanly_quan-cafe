import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import CustomerMenu from './components/public/CustomerMenu.tsx'

/**
 * Router cấp cao nhất — không dùng React Router.
 *
 * - URL có ?qr=1  → render CustomerMenu (public, không cần auth)
 * - Còn lại       → render App bình thường (dashboard nội bộ)
 *
 * Ví dụ QR URL in ra trên nhãn dán bàn:
 *   https://cafe.yourdomain.com/?qr=1&tableId=5
 */
const isQrView = new URLSearchParams(window.location.search).has('qr')

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {isQrView ? <CustomerMenu /> : <App />}
  </StrictMode>,
)