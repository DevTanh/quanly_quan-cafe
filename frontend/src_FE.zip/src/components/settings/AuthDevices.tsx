// src/components/settings/AuthDevices.tsx
import React, { useState, useEffect, useCallback } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faLaptop, faMobileAlt, faDesktop, faSignOutAlt,
  faSpinner, faSyncAlt, faShieldAlt, faGlobe,
} from '@fortawesome/free-solid-svg-icons';
import api from '../../api/api';
import { useToast } from '../../context/ToastContext';

/* ── Types ── */
interface DeviceSession {
  sessionId: string;
  userId: number;
  userFullName?: string;
  userAgent?: string;
  ipAddress?: string;
  lastActiveAt: string;
  createdAt: string;
  isCurrent?: boolean;
}

interface User {
  id: number;
  fullName: string;
  email: string;
  role: string;
  isActive: boolean;
}

/* ── Helpers ── */
function guessDevice(ua?: string): 'mobile' | 'laptop' | 'desktop' {
  if (!ua) return 'desktop';
  if (/mobile|android|iphone/i.test(ua)) return 'mobile';
  if (/tablet|ipad/i.test(ua)) return 'laptop';
  return 'desktop';
}

function getBrowser(ua?: string): string {
  if (!ua) return 'Không xác định';
  if (/chrome/i.test(ua) && !/edge/i.test(ua)) return 'Chrome';
  if (/firefox/i.test(ua)) return 'Firefox';
  if (/safari/i.test(ua) && !/chrome/i.test(ua)) return 'Safari';
  if (/edge/i.test(ua)) return 'Edge';
  return 'Trình duyệt khác';
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

const DEVICE_ICON = {
  mobile:  faMobileAlt,
  laptop:  faLaptop,
  desktop: faDesktop,
};

/* ══════════════════════════════════════════════════════════════ */
const AuthDevices: React.FC = () => {
  const toast = useToast();
  const [tab, setTab] = useState<'my' | 'all'>('my');
  const [sessions, setSessions] = useState<DeviceSession[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [revoking, setRevoking] = useState<string | null>(null);
  const [forcingLogout, setForcingLogout] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchUser, setSearchUser] = useState('');

  const fetchSessions = useCallback(async () => {
    try {
      setLoading(true);
      const { data } = await api.get<DeviceSession[]>('/auth/devices');
      const arr = Array.isArray(data) ? data : (data as any)?.data ?? [];
      setSessions(arr);
    } catch (err) {
      toast.error('Không thể tải danh sách thiết bị');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchUsers = useCallback(async () => {
    try {
      const { data } = await api.get('/users', { params: { isActive: true } });
      const arr = Array.isArray(data) ? data : (data as any)?.data ?? [];
      setUsers(arr);
    } catch (err) {
      console.error('fetchUsers error:', err);
    }
  }, []);

  useEffect(() => {
    fetchSessions();
    fetchUsers();
  }, [fetchSessions, fetchUsers]);

  const revokeDevice = async (sessionId: string) => {
    try {
      setRevoking(sessionId);
      await api.delete(`/auth/devices/${sessionId}`);
      toast.success('Đã đăng xuất thiết bị thành công');
      setSessions(prev => prev.filter(s => s.sessionId !== sessionId));
    } catch (err: any) {
      toast.error(err?.response?.data?.message ?? 'Đăng xuất thiết bị thất bại');
    } finally {
      setRevoking(null);
    }
  };

  const forceLogoutUser = async (userId: number, userName: string) => {
    try {
      setForcingLogout(userId);
      await api.post(`/auth/force-logout/${userId}`);
      toast.success(`Đã đăng xuất tất cả thiết bị của "${userName}"`);
      await fetchSessions();
    } catch (err: any) {
      toast.error(err?.response?.data?.message ?? 'Force logout thất bại');
    } finally {
      setForcingLogout(null);
    }
  };

  const filteredUsers = users.filter(u =>
    !searchUser ||
    u.fullName.toLowerCase().includes(searchUser.toLowerCase()) ||
    u.email.toLowerCase().includes(searchUser.toLowerCase()),
  );

  const getUserSessionCount = (userId: number) =>
    sessions.filter(s => s.userId === userId).length;

  return (
    <div className="p-5 font-['Segoe_UI',sans-serif] bg-[#f3f4f6] min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-[20px] font-extrabold text-gray-800 flex items-center gap-2 m-0">
            <FontAwesomeIcon icon={faShieldAlt} className="text-[#3dba74]" />
            Quản lý thiết bị đăng nhập
          </h1>
          <p className="text-[12.5px] text-gray-400 mt-0.5">
            {loading ? 'Đang tải...' : `${sessions.length} phiên đang hoạt động`}
          </p>
        </div>
        <button
          onClick={fetchSessions}
          className="flex items-center gap-2 px-3 py-2 border border-gray-200 bg-white rounded-lg text-[13px] text-gray-500 hover:bg-gray-50 transition-colors"
        >
          <FontAwesomeIcon icon={faSyncAlt} spin={loading} /> Làm mới
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-5 bg-white rounded-t-xl px-4">
        {[
          { key: 'my' as const, label: 'Phiên của tôi' },
          { key: 'all' as const, label: 'Tất cả nhân viên' },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={[
              'px-4 py-3 text-[13.5px] font-medium border-b-2 transition-colors -mb-px',
              tab === t.key
                ? 'border-[#16a34a] text-[#16a34a]'
                : 'border-transparent text-gray-500 hover:text-gray-700',
            ].join(' ')}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Tab: My Sessions ── */}
      {tab === 'my' && (
        <div className="flex flex-col gap-3">
          {loading ? (
            <div className="flex items-center justify-center py-16 gap-3 text-gray-400">
              <FontAwesomeIcon icon={faSpinner} spin className="text-2xl text-[#3dba74]" />
              <span className="text-[14px]">Đang tải thiết bị...</span>
            </div>
          ) : sessions.length === 0 ? (
            <div className="bg-white rounded-xl p-10 text-center text-gray-400">
              <FontAwesomeIcon icon={faLaptop} className="text-[48px] mb-3 text-gray-200" />
              <p className="text-[14px]">Không có phiên đăng nhập nào khác</p>
            </div>
          ) : (
            sessions.map(session => {
              const deviceType = guessDevice(session.userAgent);
              const icon = DEVICE_ICON[deviceType];
              const isRevokingThis = revoking === session.sessionId;

              return (
                <div
                  key={session.sessionId}
                  className={[
                    'bg-white rounded-xl p-4 shadow-sm border transition-all',
                    session.isCurrent
                      ? 'border-[#3dba74] bg-[#f0fdf4]'
                      : 'border-gray-100 hover:border-gray-200',
                  ].join(' ')}
                >
                  <div className="flex items-center gap-4">
                    <div className={[
                      'w-12 h-12 rounded-xl flex items-center justify-center text-[20px] shrink-0',
                      session.isCurrent ? 'bg-[#3dba74] text-white' : 'bg-gray-100 text-gray-500',
                    ].join(' ')}>
                      <FontAwesomeIcon icon={icon} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[14px] font-semibold text-gray-800">
                          {getBrowser(session.userAgent)}
                        </span>
                        {session.isCurrent && (
                          <span className="text-[11px] font-bold bg-[#3dba74] text-white px-2 py-0.5 rounded-full">
                            Phiên hiện tại
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-[12px] text-gray-400 flex-wrap">
                        {session.ipAddress && (
                          <span className="flex items-center gap-1">
                            <FontAwesomeIcon icon={faGlobe} className="text-[10px]" />
                            {session.ipAddress}
                          </span>
                        )}
                        <span>Hoạt động: {formatDate(session.lastActiveAt)}</span>
                        <span>Đăng nhập: {formatDate(session.createdAt)}</span>
                      </div>
                      {session.userAgent && (
                        <p className="text-[11px] text-gray-300 mt-0.5 truncate max-w-[400px]">
                          {session.userAgent}
                        </p>
                      )}
                    </div>

                    {!session.isCurrent && (
                      <button
                        onClick={() => revokeDevice(session.sessionId)}
                        disabled={!!revoking}
                        className="flex items-center gap-1.5 px-3 py-2 border border-red-200 text-red-600 rounded-lg text-[13px] hover:bg-red-50 transition-colors disabled:opacity-50 shrink-0"
                      >
                        {isRevokingThis
                          ? <FontAwesomeIcon icon={faSpinner} spin />
                          : <FontAwesomeIcon icon={faSignOutAlt} />}
                        Đăng xuất
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ── Tab: All Users ── */}
      {tab === 'all' && (
        <div>
          <input
            className="w-full max-w-[300px] mb-4 border border-gray-200 rounded-lg px-3 py-2 text-[13px] bg-white outline-none focus:border-[#3dba74]"
            placeholder="Tìm nhân viên..."
            value={searchUser}
            onChange={e => setSearchUser(e.target.value)}
          />
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="flex bg-gray-50 border-b border-gray-200 text-[12px] font-bold text-gray-500 uppercase px-4 py-2.5">
              <div className="flex-1">Nhân viên</div>
              <div className="w-[80px] text-center">Phiên</div>
              <div className="w-[120px] text-center">Hành động</div>
            </div>

            {filteredUsers.map(user => {
              const sessionCount = getUserSessionCount(user.id);
              const isForcing = forcingLogout === user.id;
              return (
                <div
                  key={user.id}
                  className="flex items-center px-4 py-3 border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#3dba74] flex items-center justify-center text-white text-[13px] font-bold shrink-0">
                      {user.fullName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-[13.5px] font-semibold text-gray-800 m-0">{user.fullName}</p>
                      <p className="text-[12px] text-gray-400 m-0">{user.email} · {user.role}</p>
                    </div>
                  </div>
                  <div className="w-[80px] text-center">
                    <span className={[
                      'text-[12px] font-semibold px-2 py-0.5 rounded-full',
                      sessionCount > 0 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-400',
                    ].join(' ')}>
                      {sessionCount} phiên
                    </span>
                  </div>
                  <div className="w-[120px] flex justify-center">
                    {sessionCount > 0 && (
                      <button
                        onClick={() => forceLogoutUser(user.id, user.fullName)}
                        disabled={!!forcingLogout}
                        className="flex items-center gap-1.5 px-2.5 py-1.5 border border-orange-200 text-orange-600 rounded-lg text-[12px] hover:bg-orange-50 transition-colors disabled:opacity-50"
                        title={`Đăng xuất tất cả thiết bị của ${user.fullName}`}
                      >
                        {isForcing
                          ? <FontAwesomeIcon icon={faSpinner} spin />
                          : <FontAwesomeIcon icon={faSignOutAlt} />}
                        Force logout
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredUsers.length === 0 && (
              <div className="flex items-center justify-center py-12 text-gray-300 text-[13px]">
                Không tìm thấy nhân viên
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AuthDevices;
