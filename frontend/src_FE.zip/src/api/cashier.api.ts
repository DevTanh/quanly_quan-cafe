// src/api/cashier.api.ts
// Dùng axios instance chung (có interceptor refresh-token + withCredentials)

import api from './api';
import { extractArray } from '../utils/extractArray';
import type { Zone, MenuItem } from '../types/cashier.types';
import type { CreateOrderDto, Order, CreatePaymentDto } from '../types';

export const cashierApi = {
  /**
   * GET /zones?include=tables
   * Lấy danh sách khu vực + bàn từ BE thực tế.
   */
  getTables: async (): Promise<Zone[]> => {
    const { data } = await api.get('/zones', { params: { include: 'tables' } });
    return extractArray<Zone>(data);
  },

  /**
   * Lấy danh sách món từ /products?status=active
   * Map Product → MenuItem cho POS dùng.
   */
  getMenuItems: async (): Promise<MenuItem[]> => {
    const { data } = await api.get('/products', {
      params: { status: 'active', limit: 200 },
    });
    const raw = extractArray<any>(data);
    return raw.map((p: any) => ({
      id: String(p.id),
      name: p.name,
      price: Number(p.sellingPrice),
      category: p.category?.name ?? '',
    }));
  },

  /**
   * Lấy order đang pending/processing của một bàn.
   */
  getTableOrder: async (tableId: number): Promise<Order | null> => {
    const { data } = await api.get<any>('/orders', {
      params: { tableId, status: 'pending' },
    });
    const list = extractArray<Order>(data);
    const pending = list.find(o => o.status === 'pending');
    if (pending) return pending;
    const { data: procData } = await api.get<any>('/orders', {
      params: { tableId, status: 'processing' },
    });
    return extractArray<Order>(procData)[0] ?? null;
  },

  /**
   * Lấy tất cả tableId đang có order active (pending | processing).
   * Dùng để tô màu "Đang dùng" trên sơ đồ bàn.
   */
  getOccupiedTableIds: async (): Promise<Set<number>> => {
    const [{ data: pending }, { data: processing }] = await Promise.all([
      api.get<any>('/orders', { params: { status: 'pending', limit: 200 } }),
      api.get<any>('/orders', { params: { status: 'processing', limit: 200 } }),
    ]);
    const all = [
      ...extractArray<Order>(pending),
      ...extractArray<Order>(processing),
    ];
    return new Set(all.map(o => o.tableId).filter(Boolean));
  },

  /** Tạo đơn hàng mới */
  createOrder: async (dto: CreateOrderDto): Promise<Order> => {
    const { data } = await api.post<Order>('/orders', dto);
    return data;
  },

  /** Lấy chi tiết order */
  getOrder: async (orderId: number): Promise<Order> => {
    const { data } = await api.get<Order>(`/orders/${orderId}`);
    return data;
  },

  /** Cập nhật danh sách món */
  updateOrderItems: async (
    orderId: number,
    items: { productId: number; quantity: number; note?: string }[],
  ): Promise<Order> => {
    const { data } = await api.patch<Order>(`/orders/${orderId}/items`, { items });
    return data;
  },

  /** Gửi xuống bar/bếp */
  sendToBar: async (orderId: number): Promise<Order> => {
    const { data } = await api.post<Order>(`/orders/${orderId}/send-to-bar`);
    return data;
  },

  /** Thanh toán */
  pay: async (orderId: number, dto: CreatePaymentDto): Promise<any> => {
    const { data } = await api.post(`/orders/${orderId}/payment`, dto);
    return data;
  },

  /** Hủy order */
  cancelOrder: async (orderId: number): Promise<Order> => {
    const { data } = await api.patch<Order>(`/orders/${orderId}/cancel`);
    return data;
  },

  /** Polling trạng thái thanh toán QR */
  getPaymentStatus: async (orderId: number): Promise<any> => {
    const { data } = await api.get(`/orders/${orderId}/payment-status`);
    return data;
  },
};
